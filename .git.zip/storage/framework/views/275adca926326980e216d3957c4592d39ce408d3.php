
<?php $__env->startSection('content'); ?>
    <div class="row page-titles">
        <div class="col-md-6 col-sm-6 align-self-center">
            <h3>Loan Properties Settings</h3>
        </div>
        <div class="col-md-6 col-sm-6 text-right font-12"> <a href="<?php echo e(route('admin.dashboard')); ?>">Admin</a> </div>
    </div>
    <div class="row">
        <div class="col-lg-6 col-md-12">
            <div class="card">
                <div class="card-body">
                    <h4>Add / Update Loan Duration</h4>
                    <form class="form-horizontal" method="post" action="<?php echo e(route('admin.add-duration')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="col-12 mb-5">
                            <div class="form-group">
                                <label class="control-label font-16 mb-1">Duration</label>
                                <div class="row">
                                    <div class="col-md-7">
                                        <input type="number" name="duration" class="form-control font-14" placeholder="Duration (In Months)" required>
                                    </div>
                                    <div class="col-md-5">
                                        <button type="submit" class="btn btn-sm btn-rounded btn-outline-primary">Add Duration</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                    <div class="relative">
                        <div class="table-responsive">
                            <table id="loan-duration" class="display nowrap table table-hover">
                                <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Duration</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if(count($loan_duration) > 0): ?>
                                    <?php $__currentLoopData = $loan_duration; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $duration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($duration->idloanduration); ?></td>
                                            <td><?php echo e($duration->duration); ?></td>
                                            <td>
                                                <a  data-toggle="modal" data-target="#duration<?php echo e($key); ?>" class="view-icon "><i class="fa fa-eye-slash" aria-hidden="true" title="Edit"></i></a>
                                                <a href="<?php echo e(route('admin.delete-duration', ['id'=> $duration->idloanduration])); ?>" class="delete-icon"><i class="fa fa-trash" aria-hidden="true" title="Delete"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <h5> No record Found</h5>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <h4>Add / Update Loan Rate</h4>
                    <form class="form-horizontal" method="post" action="<?php echo e(route('admin.add-rate')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="col-12 mb-5">
                            <div class="form-group">
                                <label class="control-label font-16 mb-1">Loan Rate</label>
                                <div class="row">
                                    <div class="col-md-10 mb-2">
                                        <input type="number" name="rate" class="form-control font-14" placeholder="Rate" required>
                                    </div>
                                    <div class="col-md-10 mb-2">
                                        <input type="text" name="description" class="form-control font-14" placeholder="Description" required>
                                    </div>
                                    <div class="col-md-5">
                                        <button type="submit" class="btn btn-sm btn-rounded btn-outline-primary">Add Loan Rate</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                    <div class="relative">
                        <div class="table-responsive">
                            <table id="loan-rate" class="display nowrap table table-hover">
                                <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Rate</th>
                                    <th>Description</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if(count($loan_rate) > 0): ?>
                                    <?php $__currentLoopData = $loan_rate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $rate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($rate->idloanrate); ?></td>
                                            <td><?php echo e($rate->rate); ?></td>
                                            <td><?php echo e($rate->description); ?></td>
                                            <td>
                                                <a  data-toggle="modal" data-target="#rate<?php echo e($key); ?>" class="view-icon "><i class="fa fa-eye-slash" aria-hidden="true" title="Edit"></i></a>
                                                <a href="<?php echo e(route('admin.delete-rate', ['id'=> $rate->idloanrate])); ?>" class="delete-icon"><i class="fa fa-trash" aria-hidden="true" title="Delete"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <h5> No record Found</h5>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6 col-md-12">
            <div class="card">
                <div class="card-body">
                    <h4>Add / Update Loan Range</h4>
                    <form class="form-horizontal" method="post" action="<?php echo e(route('admin.add-range')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="col-12 mb-5">
                            <div class="form-group">
                                <label class="control-label font-16 mb-1">Loan Range</label>
                                <div class="row ">
                                    <div class="col-md-4 mb-2">
                                        <input type="text" name="name" class="form-control font-14" placeholder="Name" required>
                                    </div>
                                    <div class="col-md-4">
                                        <input type="number" name="min_range" class="form-control font-14" placeholder="MIN" required>
                                    </div>
                                    <div class="col-md-4">
                                        <input type="number" name="max_range" class="form-control font-14" placeholder="MAX" required>
                                    </div>
                                    <div class="col-md-10">
                                        <button type="submit" class="btn btn-sm  btn-outline-primary">Add Range</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                    <div class="relative">
                        <div class="table-responsive">
                            <table id="loan-range" class="display nowrap table table-hover">
                                <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Name</th>
                                    <th>Mini</th>
                                    <th>Maxi</th>
                                    <th>Actions</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if(count($loan_range) > 0): ?>
                                    <?php $__currentLoopData = $loan_range; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $range): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($range ->idloanrange); ?></td>
                                            <td><?php echo e($range->name); ?></td>
                                            <td><?php echo e($range->mini_range); ?></td>
                                            <td><?php echo e($range->maxi_range); ?></td>
                                            <td>
                                                <a  data-toggle="modal" data-target="#range<?php echo e($key); ?>" class="view-icon "><i class="fa fa-eye-slash" aria-hidden="true" title="Edit"></i></a>
                                                <a href="<?php echo e(route('admin.delete-range', ['id'=> $range->idloanrange])); ?>" class="delete-icon"><i class="fa fa-trash" aria-hidden="true" title="Delete"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <h5> No record Found</h5>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <h4>Add / Update Salary Range</h4>
                    <form class="form-horizontal" method="post" action="<?php echo e(route('admin.add-salary')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="col-12 mb-5">
                            <div class="form-group">
                                <label class="control-label font-16 mb-1">Salary Range</label>
                                <div class="row">
                                    <div class="col-md-7">
                                        <input type="text" name="range" class="form-control font-14" placeholder="Range" required>
                                    </div>
                                    <div class="col-md-5">
                                        <button type="submit" class="btn btn-sm btn-rounded btn-outline-primary">Add Range</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                    <div class="relative">
                        <div class="table-responsive">
                            <table id="salary-range" class="display nowrap table table-hover">
                                <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Range</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if(count($salaries) > 0): ?>
                                    <?php $__currentLoopData = $salaries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $salary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($salary->idsalaryrange); ?></td>
                                            <td><?php echo e($salary->salary_range); ?></td>
                                            <td>
                                                <a  data-toggle="modal" data-target="#salary<?php echo e($key); ?>" class="view-icon "><i class="fa fa-eye-slash" aria-hidden="true" title="Edit"></i></a>
                                                <a href="<?php echo e(route('admin.delete-salary', ['id'=> $salary->idsalaryrange])); ?>" class="delete-icon"><i class="fa fa-trash" aria-hidden="true" title="Delete"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <h5> No record Found</h5>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__currentLoopData = $loan_range; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $range): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="range<?php echo e($key); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Loan Range</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form class="form-horizontal" method="post" action="<?php echo e(route('admin.update-range', ['id' => $range->idloanrange])); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="col-12 mb-5">
                                <div class="form-group">
                                    <label class="control-label font-16 mb-1">Name</label>
                                    <div class="row">
                                        <div class="col-md-4 mb-2">
                                            <input type="text" name="name" class="form-control font-14" value="<?php echo e($range->name); ?>" placeholder="<?php echo e($range->name); ?>" required>
                                        </div>
                                        <div class="col-md-4">
                                            <input type="number" name="min_range" class="form-control font-14" value="<?php echo e($range->mini_range); ?>" placeholder="<?php echo e($range->mini_range); ?>" required>
                                        </div>
                                        <div class="col-md-4">
                                            <input type="number" name="max_range" class="form-control font-14" value="<?php echo e($range->maxi_range); ?>" placeholder="<?php echo e($range->maxi_range); ?>" required>
                                        </div>
                                        <div class="col-md-10">
                                            <button type="submit" class="btn btn-sm btn-rounded btn-outline-primary">Update Loan Range</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__currentLoopData = $salaries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $salary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="salary<?php echo e($key); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Salary Range</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form class="form-horizontal" method="post" action="<?php echo e(route('admin.update-salary', ['id' => $salary->idsalaryrange])); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="col-12 mb-5">
                                <div class="form-group">
                                    <label class="control-label font-16 mb-1">Range</label>
                                    <div class="row">
                                        <div class="col-md-5">
                                            <input type="name" name="range" value="<?php echo e($salary->range); ?>" class="form-control font-14" placeholder="<?php echo e($salary->range); ?>" required>
                                        </div>
                                        <div class="col-md-6">
                                            <button type="submit" class="btn btn-sm btn-rounded btn-outline-primary">Update Salary Range</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__currentLoopData = $loan_duration; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $duration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="duration<?php echo e($key); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Loan Duration</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form class="form-horizontal" method="post" action="<?php echo e(route('admin.update-duration', ['id' => $duration->idloanduration])); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="col-12 mb-5">
                                <div class="form-group">
                                    <label class="control-label font-16 mb-1">Duration</label>
                                    <div class="row">
                                        <div class="col-md-5">
                                            <input type="number" name="duration" value="<?php echo e($duration->duration); ?>" class="form-control font-14" placeholder="<?php echo e($duration->duration); ?>" required>
                                        </div>
                                        <div class="col-md-6">
                                            <button type="submit" class="btn btn-sm btn-rounded btn-outline-primary">Update Loan Duration</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__currentLoopData = $loan_rate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $rate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="rate<?php echo e($key); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Loan Rate</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form class="form-horizontal" method="post" action="<?php echo e(route('admin.update-rate', ['id' => $rate->idloanrate])); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="col-12 mb-5">
                                <div class="form-group">
                                    <label class="control-label font-16 mb-1">Loan Rate</label>
                                    <div class="row">
                                        <div class="col-md-10 mb-2">
                                            <input type="number" name="rate" value="<?php echo e($rate->rate); ?>" class="form-control font-14" placeholder="<?php echo e($rate->rate); ?>" required>
                                        </div>
                                        <div class="col-md-10 mb-2">
                                            <input type="text" name="description" value="<?php echo e($rate->description); ?>" class="form-control font-14" placeholder="<?php echo e($rate->description); ?>" required>
                                        </div>
                                        <div class="col-md-6">
                                            <button type="submit" class="btn btn-sm btn-rounded btn-outline-primary">Update Loan Rate</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Foodxme\SkyLoan\resources\views/Admin/Pages/system-settings.blade.php ENDPATH**/ ?>