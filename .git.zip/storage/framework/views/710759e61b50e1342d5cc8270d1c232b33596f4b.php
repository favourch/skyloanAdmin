
<?php $__env->startSection('content'); ?>
    <div class="row page-titles">
        <div class="col-md-6 col-sm-6 align-self-center">
            <h3>All Loans</h3>
        </div>
        <div class="col-md-6 col-sm-6 text-right font-12"> <a href="<?php echo e(route('admin.dashboard')); ?>">Admin</a> </div>
    </div>
    <div class="row">
        <div class="clearfix"></div>
        <div class="col-md-12">
            <div class="card">
                <h5 class="pt-3 pl-3">Loan Management</h5>
                <div class="card-body">
                    <div class="row">
                        <div class="col-12">
                            <div class="table-responsive">
                                <table id="example23" class="display nowrap table table-hover">
                                    <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Loan Type</th>
                                        <th>Status</th>
                                        <th>Start Date</th>
                                        <th>Loan Duration</th>
                                        <th>Loan Information</th>
                                        <th>Amount</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                        

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Foodxme\SkyLoan\resources\views/Admin/Pages/pending-loans.blade.php ENDPATH**/ ?>