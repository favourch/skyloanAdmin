
<?php $__env->startSection('content'); ?>
    <div class="row page-titles">
        <div class="col-md-6 col-sm-6 align-self-center">
            <h3>Users - <?php echo e($user->fullname); ?></h3>
        </div>
        <div class="col-md-6 col-sm-6 text-right font-12"> <a href="<?php echo e(route('admin.dashboard')); ?>">Admin</a> </div>
    </div>
    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="card">
                <div class="card-body">
                    <h4> General </h4>
                    <div class="row">
                        <div class="form-wrap form-wrap2 col-12">
                            <form class="form-horizontal">
                                <div>
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-6 col-xs-12 mb-10">
                                                <label class="control-label font-16 mb-1">Full Name</label>
                                                <div>
                                                    <input type="email" class="form-control font-14" value="<?php echo e($user->fullname); ?>" disabled>
                                                </div>
                                            </div>
                                            <div class="col-sm-6 col-xs-12 mb-10">
                                                <label class="control-label font-16 mb-1">Email</label>
                                                <div>
                                                    <input type="email" class="form-control font-14" value="<?php echo e($user->email); ?>" disabled>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                                <div>
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-4 col-xs-12 mb-10">
                                                <label class="control-label font-16 mb-1">Sex</label>
                                                <div>
                                                    <input type="email" class="form-control font-14" value="<?php if($user->sex): ?><?php echo e($user->sex == 1? "Female" : "Male"); ?> <?php else: ?> Null <?php endif; ?>" disabled>
                                                </div>
                                            </div>
                                            <div class="col-sm-4 col-xs-12 mb-10">
                                                <label class="control-label font-16 mb-1">Local Government</label>
                                                <div>
                                                    <input type="email" class="form-control font-14" value="<?php if($user->lgs): ?><?php echo e($user->lgs->lgs); ?> <?php else: ?> Nill <?php endif; ?>"  disabled>
                                                </div>
                                            </div>
                                            <div class="col-sm-4 col-xs-12 mb-10">
                                                <label class="control-label font-16 mb-1">State</label>
                                                <div>
                                                    <input type="email" class="form-control font-14" value="<?php if($user->state): ?><?php echo e($user->state->names); ?> <?php else: ?> Nill <?php endif; ?>" disabled>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                                <div>
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-6 col-xs-12 mb-10">
                                                <label class="control-label font-16 mb-1">Address</label>
                                                <div>
                                                    <input type="email" class="form-control font-14" value="<?php if($user->address): ?><?php echo e($user->address); ?> <?php else: ?> Nill <?php endif; ?>" disabled>
                                                </div>
                                            </div>
                                            <div class="col-sm-3 col-xs-12 mb-10">
                                                <label class="control-label font-16 mb-1">Marital Status</label>
                                                <div>
                                                    <input type="email" class="form-control font-14" value="<?php if($user->marital_status): ?><?php echo e($user->marital_status == 1 ? "Single" : " Married"); ?> <?php else: ?> Nill <?php endif; ?>" disabled>
                                                </div>
                                            </div>
                                            <div class="col-sm-3 col-xs-12 mb-10">
                                                <label class="control-label font-16 mb-1">DOB</label>
                                                <div>
                                                    <input type="email" class="form-control font-14" value="<?php if($user->dob): ?> <?php echo e($user->dob); ?> <?php else: ?> Nill <?php endif; ?>" disabled>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <h4> Next of Kin </h4>
                    <?php if(!empty($next_of_kin)): ?>
                        <div class="row">
                            <div class="col-lg-4 col-md-12">
                                <div class="form-group">
                                    <label class="control-label font-14 mb-1">Phone Number</label>
                                    <div>
                                        <input type="text" class="form-control font-14" value="<?php echo e($next_of_kin->phone_number); ?>" disabled>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-12">
                                <div class="form-group">
                                    <label class="control-label font-14 mb-1">Email</label>
                                    <input type="text" class="form-control font-14" value="<?php echo e($next_of_kin->email); ?>" disabled >
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-12">
                                <div class="form-group">
                                    <label class="control-label font-14 mb-1">Relationship</label>
                                    <input type="text" class="form-control font-14" value="<?php echo e($next_of_kin->relationship); ?>" disabled >
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-6 col-md-12">
                                <div class="form-group">
                                    <label class="control-label font-14 mb-1">Address</label>
                                    <div>
                                        <input type="text" class="form-control font-14" value="<?php echo e($next_of_kin->address); ?>" disabled>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12">
                                <div class="form-group">
                                    <label class="control-label font-14 mb-1">State</label>
                                    <input type="text" class="form-control font-14" value="<?php echo e($next_of_kin->state->names); ?>" disabled >
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12">
                                <div class="form-group">
                                    <label class="control-label font-14 mb-1">Local Goverment</label>
                                    <input type="text" class="form-control font-14" value="<?php echo e($next_of_kin->lgs->lgs); ?>" disabled >
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <div>
                            <span class="control-label font-14 mb-1 text-danger">Next Of Kin Information is not Updated Yet by the User</span>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/skylwoyo/admin.skyloan.today/resources/views/Admin/Pages/user-details.blade.php ENDPATH**/ ?>