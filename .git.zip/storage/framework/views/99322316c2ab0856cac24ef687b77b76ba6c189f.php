
<?php $__env->startSection('content'); ?>
    <div class="row page-titles">
        <div class="col-md-6 col-sm-6 align-self-center">
            <h3>All Loans</h3>
        </div>
        <div class="col-md-6 col-sm-6 text-right font-12"> <a href="<?php echo e(route('admin.dashboard')); ?>">Admin</a> </div>
    </div>
    <div class="row">
        <div class="clearfix"></div>
        <div class="col-md-12">
            <div class="card">
                <h5 class="pt-3 pl-3">Loan Management</h5>
                <div class="card-body">
                    <div class="row">
                        <div class="col-12">
                            <div class="table-responsive">
                                <table id="example23" class="display nowrap table table-hover">
                                    <thead>
                                    <tr>
                                        <th>Name</th>
                                        
                                        <th>Loan Type</th>
                                        <th>Status</th>
                                        <th>Start Date</th>
                                        <th>End Date</th>
                                        <th>Loan Information</th>
                                        <th>Amount</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$loan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loan->user->fullname); ?></td>
                                            
                                            <td><?php echo e($loan->loanRange->name); ?></td>
                                            <td>
                                                <?php if($loan->loan_status == 4): ?>
                                                    <span class="btn waves-effect waves-light btn-rounded close-bt">Finished</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($loan->loan_status == 1): ?>
                                                    Nill
                                                <?php else: ?>
                                                    <?php echo e($loan->loan_start_date); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php
                                                $date =  new \Carbon\Carbon($loan->loan_start_date);
                                                $end_date = $date->addDays($loan->loanDuration->duration);
                                                $end_date = $end_date->format('Y-m-d');
                                                ?>
                                                <?php echo e($end_date); ?>

                                            </td>
                                            <td>
                                                <a  data-toggle="modal" data-target="#information<?php echo e($key); ?>" ><span class="btn waves-effect waves-light btn-rounded close-bt">View Loan Information</span></a>
                                            </td>
                                            <td>
                                                <?php echo e(number_format($loan->amount)); ?>

                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('admin.view-user-details', ['id' => $loan->user_id])); ?>" class="view-icon"><i class="fa fa-eye" aria-hidden="true" title="View User Details"></i></a>
                                                <a  data-toggle="modal" data-target="#bank<?php echo e($key); ?>" class="pencil-icon" ><i class="fa fa-bank" aria-hidden="true" title="View Bank Account"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__currentLoopData = $loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $information): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="information<?php echo e($key); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Reason For Loan Application</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <h5 class="modal-title" id="exampleModalLabel">
                            <?php echo e($information->loan_info); ?>

                        </h5>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__currentLoopData = $loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="bank<?php echo e($key); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Bank Account Information</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <?php $bank_info = \App\BankInformation::where('user_id', $bank->user_id)->first() ?>
                    <div class="modal-body">
                        <div class="col-12 mb-5">
                            <div class="form-group">

                                <div class="row">
                                    <div class="col-md-6 mb-2">
                                        <label class="control-label font-16 mb-1">Name</label>
                                        <input type="text" name="name" class="form-control font-14" value="<?php echo e($loan->user->fullname); ?>" placeholder="<?php echo e($loan->user->fullname); ?>" disabled>
                                    </div>
                                    <div class="col-md-4">
                                        <label class="control-label font-16 mb-1">Account Number</label>
                                        <input type="number" name="min_range" class="form-control font-14" value="<?php echo e($bank_info->account_number); ?>" placeholder="<?php echo e($bank_info->account_number); ?>" disabled>
                                    </div>
                                    <div class="col-md-4">
                                        <label class="control-label font-16 mb-1">Account Name</label>
                                        <input type="text" name="max_range" class="form-control font-14" value="<?php echo e($bank_info->bank->name); ?>" placeholder="<?php echo e($bank_info->bank->name); ?>" disabled>
                                    </div>
                                    <div class="col-md-4">
                                        <label class="control-label font-16 mb-1">BVN</label>
                                        <input type="number" name="max_range" class="form-control font-14" value="<?php echo e($bank_info->bvn); ?>" placeholder="<?php echo e($bank_info->bvn); ?>" disabled>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/skylwoyo/admin.skyloan.today/resources/views/Admin/Pages/mature-loans.blade.php ENDPATH**/ ?>