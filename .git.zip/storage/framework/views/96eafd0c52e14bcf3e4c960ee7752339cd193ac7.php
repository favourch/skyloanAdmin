<footer class="footer">
    <div class="row">
        <div class="col-md-6 col-sm-6 font-12">Copyrights 20120. SkyLoan Admin All Rights Reserved</div>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\Foodxme\SkyLoan\resources\views/Admin/layouts/footer.blade.php ENDPATH**/ ?>