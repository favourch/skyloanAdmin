<aside class="left-sidebar">
    <!-- Sidebar scroll-->
    <div class="scroll-sidebar">
        <!-- Sidebar navigation-->
        <nav class="sidebar-nav">
            <ul id="sidebarnav">


                <li> <a class="waves-effect waves-dark" href="#" aria-expanded="false"><i class="mdi mdi-monitor e mr-10"></i><span class="hide-menu">Skyloan Admin</span></a></li>


                <li> <a class="waves-effect waves-dark" href="<?php echo e(route('admin.dashboard')); ?>">
                        <span class="hide-menu">Dashboard</span></a>
                </li>
                <li>
                    <a class="waves-effect waves-dark" href="<?php echo e(route('admin.user-management')); ?>">
                        <i class="fa fa-users"></i><span class="hide-menu"> User Management</span>
                    </a>
                </li>
                <li>
                    <a class="has-arrow waves-effect waves-dark" href="#" aria-expanded="false"> <i class="fa fa-money"></i> <span class="hide-menu">Loan Management</span></a>
                    <ul aria-expanded="false" class="collapse">
                        <li><a href="<?php echo e(route('admin.check-pending-loans')); ?>">Pending Loans</a></li>
                        <li><a href="<?php echo e(route('admin.check-active-loans')); ?>">Active Loans</a></li>
                        <li><a href="<?php echo e(route('admin.check-overdue-loans')); ?>">Overdue</a>	</li>
                        <li><a href="<?php echo e(route('admin.check-mature-loans')); ?>">Matured Loans</a></li>
                    </ul>
                </li>
                
                <li>
                    <a class="has-arrow waves-effect waves-dark" href="#" aria-expanded="false"> <i class="fa fa-cog"></i> <span class="hide-menu">System Settings</span></a>
                    <ul aria-expanded="false" class="collapse">
                        <li><a href="<?php echo e(route('admin.loan-system-settings')); ?>">Loan Properties</a></li>
                        <li><a href="<?php echo e(route('admin.lg-state-system-settings')); ?>">LGS/State Settings</a></li>
                        <li><a href="<?php echo e(route('admin.others-system-settings')); ?>">Others</a>	</li>
                    </ul>
                </li>
                <li>
                    <a class="waves-effect waves-dark" href="<?php echo e(route('admin.view-contact-message')); ?>">
                        <i class="fa fa-envelope"></i><span class="hide-menu"> Contact Us</span>
                    </a>
                </li>
                <li>
                    <a class="waves-effect waves-dark" href="<?php echo e(route('admin.logout')); ?>">
                      <i class="fa fa-sign-out"></i><span class="hide-menu"> Logout</span>
                    </a>
                </li>

                




            </ul>
        </nav>
        <!-- End Sidebar navigation -->
    </div>
    <!-- End Sidebar scroll-->
</aside>
<?php /**PATH C:\xampp\htdocs\Foodxme\SkyLoan\resources\views/Admin/layouts/sidebar.blade.php ENDPATH**/ ?>