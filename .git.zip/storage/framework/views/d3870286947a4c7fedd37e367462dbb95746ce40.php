
<?php $__env->startSection('content'); ?>
    <div class="row page-titles">
        <div class="col-md-6 col-sm-6 align-self-center">
            <h3>Registered Users</h3>
        </div>
        <div class="col-md-6 col-sm-6 text-right font-12"> <a href="<?php echo e(route('admin.dashboard')); ?>">Admin</a> </div>
    </div>
    <div class="row">
        <div class="clearfix"></div>
        <div class="col-md-12">
            <div class="card">
                <h5 class="pt-3 pl-3">Registered Users</h5>
                <div class="card-body">
                    <div class="row">
                        <div class="col-12">
                            <div class="table-responsive">
                                <table id="example23" class="display nowrap table table-hover">
                                    <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Status</th>
                                        <th>Marital Status</th>
                                        <th>Sex</th>
                                        <th>State</th>
                                        <th>Lgs</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($user->fullname); ?></td>
                                                <td><?php echo e($user->email); ?></td>
                                                <td> <?php if($user->status == 0): ?>
                                                         <span class="btn waves-effect waves-light btn-rounded pending-bt">Pending</span>
                                                     <?php elseif($user->status == 1): ?>
                                                        <span class="btn waves-effect waves-light btn-rounded close-bt">Verified</span>
                                                     <?php else: ?>
                                                         <span class="btn waves-effect waves-light btn-rounded open-bt">Suspended</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if($user->marital_status == 1): ?>
                                                        Single
                                                    <?php endif; ?>
                                                    <?php if($user->marital_status == 2): ?>
                                                        Married
                                                    <?php endif; ?>
                                                    <?php if($user->marital_status == null): ?>
                                                        Nil
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if($user->sex == 1): ?>
                                                        Male
                                                    <?php endif; ?>
                                                    <?php if($user->sex == 2): ?>
                                                        Female
                                                    <?php endif; ?>
                                                    <?php if($user->marital_status == null): ?>
                                                        Nill
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php if($user->state): ?>
                                                        <?php echo e($user->state->names); ?>

                                                    <?php else: ?>
                                                        nil
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if($user->lgs): ?>
                                                        <?php echo e($user->lgs->lgs); ?>

                                                    <?php else: ?>
                                                        nil
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if($user->status == 0): ?>
                                                         <a href="<?php echo e(route('admin.approve-user', ['id' => $user->idusers])); ?>" class="pencil-icon"><i class="fa fa-check" aria-hidden="true" title="Approve User"></i></a>
                                                    <?php endif; ?>
                                                    <?php if($user->status == 1): ?>
                                                        <a href="<?php echo e(route('admin.reject-user', ['id' => $user->idusers])); ?>" class="delete-icon"><i class="fa fa-trash-o" aria-hidden="true" title="Dis-approve User"></i></a>
                                                        <a href="<?php echo e(route('admin.suspend-user', ['id' => $user->idusers])); ?>" class="suspend-icon"><i class="fa fa-times" aria-hidden="true" title="Suspend User"></i></a>
                                                    <?php endif; ?>
                                                    <a href="<?php echo e(route('admin.view-user-details', ['id' => $user->idusers])); ?>" class="view-icon"><i class="fa fa-eye" aria-hidden="true" title="View Details"></i></a>
                                                    <?php if($user->role_id == 1 ): ?>
                                                         <a href="<?php echo e(route('admin.make-admin', ['id' => $user->idusers])); ?>" class="pencil-icon"><i class="fa fa-user-plus" aria-hidden="true" title="Make Admin"></i></a>
                                                    <?php endif; ?>
                                                    <?php if($user->role_id == 2): ?>
                                                        <a href="<?php echo e(route('admin.remove-admin', ['id' => $user->idusers])); ?>" class="delete-icon"><i class="fa fa-user-secret" aria-hidden="true" title="Remove Admin"></i></a>
                                                    <?php endif; ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Foodxme\SkyLoan\resources\views/Admin/Pages/user-management.blade.php ENDPATH**/ ?>