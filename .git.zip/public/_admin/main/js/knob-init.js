"use strict";
$(function() {
	$('[data-plugin="knob"]').knob();
});