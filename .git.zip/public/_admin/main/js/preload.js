"use strict";
$(function() {
$(".preloader").fadeOut();
});