<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Passcode extends Model
{
    protected $fillable = [
      'password'
    ];
}
